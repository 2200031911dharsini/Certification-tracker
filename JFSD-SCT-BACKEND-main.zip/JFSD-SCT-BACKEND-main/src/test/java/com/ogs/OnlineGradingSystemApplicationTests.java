package com.ogs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineGradingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
