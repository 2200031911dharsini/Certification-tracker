package com.ogs.controller;

public class LecturerController {

}
