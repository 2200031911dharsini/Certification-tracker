package com.ogs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogs.model.Grade;

public interface GradeRepository extends JpaRepository<Grade, Long>{

}
