package com.ogs.service;

public class StudentServiceImpl implements StudentService{
	

}
