package com.ogs.service;

public class LecturerServiceImpl implements LecturerService{

}
