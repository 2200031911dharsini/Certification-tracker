package com.ogs.service;

public interface LecturerService {

}
